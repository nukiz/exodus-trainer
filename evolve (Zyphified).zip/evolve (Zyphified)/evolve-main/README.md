## evolve

**evolve** developers only github

here developers may commit and or create evolve related projects and folders.

developers can also add to this list and update it. a webhook will be made to discord for some updates.

consult everyone first!

current ones with access:
nukiz
alex
lava
zyph
jaffander55

## to do

- [x] loader + database system
- [x] gather up developers for the cheat
- [ ] server for database and secure platform for passwords/databasse
- [ ] the first cheat
- [ ] ideas for games
- [ ] maybe an universal launcher for no extra downloads?
- [ ] finish up
